import matplotlib.pyplot as plt


names = [2007, 2008]
values = [1, 10]

plt.figure(1, figsize=(9, 3))

plt.subplot(131)
plt.bar(names, values)
plt.subplot(132)
plt.scatter(names, values)
plt.subplot(133)
plt.plot(names, values)
plt.suptitle('Categorical Plotting')
plt.show()

"""

fig1 = plt.figure(1)
plt.plot([0, 1, 2, 3, 4], [0, 1, 2, 3, 4], label="Test", color='g')
plt.plot([0, 1, 2, 3, 4], [0, 1, 4, 9, 16],  label="Other Test",  color='r')
plt.grid(True)

#fig1.savefig('Foo1.png')
# add plt.close() after you've saved the figure
plt.close()

fig2 = plt.figure(2)
plt.plot([0, 1, 2, 3, 4], [0, 5, 1, 9, 2], label="Test 2", color='g')
plt.plot([0, 1, 2, 3, 4], [0, 10, 50, 0, 10],  label="Other Test 2",  color='r')
plt.grid(True)

#fig2.savefig('Foo2.png')

plt.show()

"""




#plt.set_title('style: {!r}'.format(sty), color='C0')
plt.plot([2007, 2008, 2009, 2010], [1, 4, 9, 56],color='blue',linestyle=':',markerfacecolor='blue', markersize=14,label='test')
plt.plot([2007, 2008, 2009, 2010], [-20, 5, 14, 40],color='green',linestyle='--',markerfacecolor='blue', markersize=12)
plt.plot([2007, 2008, 2009, 2010], [-10, 2, 24, 50],color='red',linestyle='-.',markerfacecolor='blue', markersize=12)
plt.plot([2007, 2008, 2009, 2010], [-10, 2, 24, 50],color='red',linestyle='-',markerfacecolor='blue', markersize=12)

#plt.plot(x, y, color='green', linestyle='dashed', marker='o',
   #  markerfacecolor='blue', markersize=12)
#plt.colors(['#000'])
#plt.plot([250, 350, 400, 300])
"""plt.plot([250, 350, 400, 300])
plt.plot([150, 320, 300, 225])
plt.plot([150, 220, 400, 125])
plt.plot([100, 50, 200, 205])"""
#plt.ylabel('Test')
plt.show()



"""
import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0, 1, 10)
for i in range(1, 6):
    plt.plot(x, i * x + i, label='$y = {i}x + {i}$'.format(i=i))
plt.legend(loc='best')
plt.show()
"""